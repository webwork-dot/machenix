<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body py-1 my-0">
        <div class="row">
          <div class="col-12 col-sm-4 mb-1">
            <div class="form-group">
              <label>Batch No <span class="required">*</span></label>
              <select class="form-control select2" name="batch_no" id="batch_no" required>
                <option value="">Select</option>
                <?php foreach ($po as $key => $value): ?>
                  <option value="<?php echo $value['voucher_no']; ?>"><?php echo $value['voucher_no']; ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="col-12 col-sm-4 mb-1 d-flex align-items-end">
            <button type="button" class="btn btn-primary me-1 mb-1" id="view-batch-btn">
              <?php echo get_phrase('View'); ?>
            </button>
          </div>
        </div>

        <div id="batch-detail-wrap" class="d-none">
          <div class="row mt-2">
            <div class="col-12 col-sm-4 mb-1">
              <label class="mb-25">BOE No</label>
              <input type="text" class="form-control form-control-sm" id="view-boe-no" readonly>
            </div>
            <div class="col-12 col-sm-4 mb-1">
              <label class="mb-25">BOE Date</label>
              <input type="text" class="form-control form-control-sm" id="view-boe-date" readonly>
            </div>
            <div class="col-12 col-sm-4 mb-1">
              <label class="mb-25">Received Date</label>
              <input type="text" class="form-control form-control-sm" id="view-received-date" readonly>
            </div>
            <div class="col-12 col-sm-4 mb-1">
              <label class="mb-25">Loading Date</label>
              <input type="text" class="form-control form-control-sm" id="view-loading-date" readonly>
            </div>
            <div class="col-12 col-sm-4 mb-1">
              <label class="mb-25">PO Date</label>
              <input type="text" class="form-control form-control-sm" id="view-po-date" readonly>
            </div>
          </div>

          <div class="mt-2" id="supplier-table-wrap"></div>

        </div>
      </div>
    </div>
  </div>
</div>

<script>
  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function toNum(v) {
    const n = parseFloat(v);
    return isNaN(n) ? 0 : n;
  }

  function fmt(v, d = 2) {
    return toNum(v).toFixed(d);
  }

  function setHeaderFields(header) {
    $('#view-boe-no').val(header?.boe_no || '');
    $('#view-boe-date').val(header?.boe_date || '');
    $('#view-received-date').val(header?.received_date || '');
    $('#view-loading-date').val(header?.loading_date || '');
    $('#view-po-date').val(header?.po_date || '');
  }

  function renderSupplierTables(suppliers, grandTotals, expenseItems, supplierAccounts) {
    const $wrap = $('#supplier-table-wrap');
    $wrap.empty();

    if (!Array.isArray(suppliers) || suppliers.length === 0) {
      $wrap.html('<div class="alert alert-info mb-0">No product line items found for this batch.</div>');
      return;
    }

    suppliers.forEach((supplier, supplierIdx) => {
      const products = Array.isArray(supplier.products) ? supplier.products : [];
      const totals = supplier.totals || {};

      let rowsHtml = '';
      products.forEach((p, i) => {
        rowsHtml += `
          <tr>
            <td class="text-center">${i + 1}</td>
            <td>${escapeHtml(p.product_name)}</td>
            <td>${escapeHtml(p.model_no)}</td>
            <td>${escapeHtml(p.hsn_code)}</td>
            <td class="text-end">${fmt(p.official_qty, 0)}</td>
            <td class="text-end">${fmt(p.black_qty, 0)}</td>
            <td class="text-end">${fmt(p.act_qty, 0)}</td>
            <td class="text-end">${fmt(p.cbm_per_pc, 5)}</td>
            <td class="text-end">${fmt(p.off_cbm_total, 5)}</td>
            <td class="text-end">${fmt(p.actual_cbm_total, 5)}</td>
            <td class="text-end">${fmt(p.actual_cost_with_exp, 2)}</td>
            <td class="text-end">${fmt(p.rmb_per_pc, 5)}</td>
            <td class="text-end">${fmt(p.rmb_total, 5)}</td>
            <td class="text-end">${fmt(p.usd_per_pc, 5)}</td>
            <td class="text-end">${fmt(p.usd_total, 5)}</td>
            <td class="text-end">${fmt(p.cost_without_expense_rs, 5)}</td>
            <td class="text-end">${fmt(p.total_rs_without_expense, 5)}</td>
            <td class="text-end">${fmt(p.off_usd_per_pc, 5)}</td>
            <td class="text-end">${fmt(p.total_off_usd, 5)}</td>
            <td class="text-end">${fmt(p.off_rs_per_pc, 5)}</td>
            <td class="text-end">${fmt(p.total_off_rs, 5)}</td>
            <td class="text-end">${fmt(p.off_duty_percent, 2)}</td>
            <td class="text-end">${fmt(p.off_duty_amt, 2)}</td>
            <td class="text-end">${fmt(p.off_surcharge, 2)}</td>
            <td class="text-end">${fmt(p.off_taxable_value, 2)}</td>
            <td class="text-end">${fmt(p.off_gst_percent, 2)}</td>
            <td class="text-end">${fmt(p.off_gst_amt, 2)}</td>
            <td class="text-end">${fmt(p.total_duty_gst, 2)}</td>
            <td class="text-end">${fmt(p.expense, 2)}</td>
            <td class="text-end">${fmt(p.total_expense, 2)}</td>
            <td class="text-end">${fmt(p.official_expense, 2)}</td>
            <td class="text-end">${fmt(p.total_official_expense, 2)}</td>
            <td class="text-end">${fmt(p.official_exp_per_pc, 2)}</td>
          </tr>
        `;
      });

      if (rowsHtml === '') {
        rowsHtml = '<tr><td colspan="32" class="text-center">No records</td></tr>';
      }

      function formatDate(dateStr) {
        if (!dateStr || dateStr === '0000-00-00') return '-';
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return dateStr;
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return `${date.getDate().toString().padStart(2, '0')}-${months[date.getMonth()]}-${date.getFullYear()}`;
      }

      const tableHtml = `
        <div class="supplier-section mb-2">
          <h6 class="mb-1">
            Supplier: ${escapeHtml(supplier.supplier_name || ('Supplier ' + (supplierIdx + 1)))}
            ${supplier.invoice ? `
              <span class="badge badge-soft-primary ms-1" style="font-size: 0.8rem; background: #eef2ff; color: #4338ca; border: 1px solid #c7d2fe;">
                <i class="fa fa-file me-1"></i> Inv: ${escapeHtml(supplier.invoice)}
              </span>
              <span class="badge badge-soft-secondary ms-1" style="font-size: 0.8rem; background: #f8fafc; color: #475569; border: 1px solid #e2e8f0;">
                <i class="fa fa-calendar-alt me-1"></i> ${formatDate(supplier.invoice_date)}
              </span>
            ` : ''}
          </h6>
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-sm mb-0">
              <thead>
                <tr>
                  <th>Sr No.</th>
                  <th>Product Name</th>
                  <th>Model No</th>
                  <th>HSN Code</th>
                  <th>Official Qty</th>
                  <th>Black Qty</th>
                  <th>Act Qty</th>
                  <th>CBM per pc</th>
                  <th>OFF CBM Total</th>
                  <th>Actual CBM Total</th>
                  <th>Act Cost With Expense Rs.</th>
                  <th>RMB per pc</th>
                  <th>RMB Total</th>
                  <th>USD per pc</th>
                  <th>USD Total</th>
                  <th>Cost Without Expense Rs.</th>
                  <th>Total Rs. Without Expense</th>
                  <th>OFF USD per pc</th>
                  <th>Total OFF. USD</th>
                  <th>OFF Rs per pc</th>
                  <th>Total OFF Rs.</th>
                  <th>OFF Duty %</th>
                  <th>OFF Duty Amt</th>
                  <th>OFF Surcharge 10%</th>
                  <th>OFF Taxable V.</th>
                  <th>OFF GST%</th>
                  <th>OFF GST Amt</th>
                  <th>Total Duty + GST</th>
                  <th>Expense</th>
                  <th>Total Expense</th>
                  <th>Off Expense</th>
                  <th>Off Total Expense</th>
                  <th>Off per pc</th>
                </tr>
              </thead>
              <tbody>${rowsHtml}</tbody>
              <tfoot>
                <tr class="font-weight-bold">
                  <td colspan="4" class="text-end">TOTAL</td>
                  <td class="text-end">${fmt(totals.official_qty, 0)}</td>
                  <td class="text-end">${fmt(totals.black_qty, 0)}</td>
                  <td class="text-end">${fmt(totals.act_qty, 0)}</td>
                  <!-- <td class="text-end">${fmt(totals.cbm_per_pc, 5)}</td> -->
                  <td class="text-end">-</td>
                  <td class="text-end">${fmt(totals.off_cbm_total, 5)}</td>
                  <td class="text-end">${fmt(totals.actual_cbm_total, 5)}</td>
                  <!-- <td class="text-end">${fmt(totals.actual_cost_with_exp, 2)}</td> -->
                  <td class="text-end">-</td>
                  <!-- <td class="text-end">${fmt(totals.rmb_per_pc, 5)}</td> -->
                  <td class="text-end">-</td>
                  <td class="text-end">${fmt(totals.rmb_total, 5)}</td>
                  <!-- <td class="text-end">${fmt(totals.usd_per_pc, 5)}</td> -->
                  <td class="text-end">-</td>
                  <td class="text-end">${fmt(totals.usd_total, 5)}</td>
                  <!-- <td class="text-end">${fmt(totals.cost_without_expense_rs, 5)}</td> -->
                  <td class="text-end">-</td>
                  <td class="text-end">${fmt(totals.total_rs_without_expense, 5)}</td>
                  <!-- <td class="text-end">${fmt(totals.off_usd_per_pc, 5)}</td> -->
                  <td class="text-end">-</td>
                  <td class="text-end">${fmt(totals.total_off_usd, 5)}</td>
                  <!-- <td class="text-end">${fmt(totals.off_rs_per_pc, 5)}</td> -->
                  <td class="text-end">-</td>
                  <td class="text-end">${fmt(totals.total_off_rs, 5)}</td>
                  <!-- <td class="text-end">${fmt(totals.off_duty_percent, 2)}</td> -->
                  <td class="text-end">-</td>
                  <td class="text-end">${fmt(totals.off_duty_amt, 2)}</td>
                  <td class="text-end">${fmt(totals.off_surcharge, 2)}</td>
                  <td class="text-end">${fmt(totals.off_taxable_value, 2)}</td>
                  <!-- <td class="text-end">${fmt(totals.off_gst_percent, 2)}</td> -->
                  <td class="text-end">-</td>
                  <td class="text-end">${fmt(totals.off_gst_amt, 2)}</td>
                  <td class="text-end">${fmt(totals.total_duty_gst, 2)}</td>
                  <td class="text-end">${fmt(totals.expense, 2)}</td>
                  <td class="text-end">${fmt(totals.total_expense, 2)}</td>
                  <td class="text-end">${fmt(totals.official_expense, 2)}</td>
                  <td class="text-end">${fmt(totals.total_official_expense, 2)}</td>
                  <!-- <td class="text-end">${fmt(totals.official_exp_per_pc, 2)}</td> -->
                  <td class="text-end">-</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      `;

      $wrap.append(tableHtml);
    });

    const g = grandTotals || {};
    $wrap.append(`
      <div class="supplier-section mb-2">
        <h6 class="mb-1">Grand Total</h6>
        <div class="table-responsive">
          <table class="table table-bordered table-striped table-sm mb-0">
            <thead>
              <tr>
                <th colspan="4">#</th>
                <th>Official Qty</th>
                <th>Black Qty</th>
                <th>Act Qty</th>
                <th>CBM per pc</th>
                <th>OFF CBM Total</th>
                <th>Actual CBM Total</th>
                <th>Act Cost With Expense Rs.</th>
                <th>RMB per pc</th>
                <th>RMB Total</th>
                <th>USD per pc</th>
                <th>USD Total</th>
                <th>Cost Without Expense Rs.</th>
                <th>Total Rs. Without Expense</th>
                <th>OFF USD per pc</th>
                <th>Total OFF. USD</th>
                <th>OFF Rs per pc</th>
                <th>Total OFF Rs.</th>
                <th>OFF Duty %</th>
                <th>OFF Duty Amt</th>
                <th>OFF Surcharge 10%</th>
                <th>OFF Taxable V.</th>
                <th>OFF GST%</th>
                <th>OFF GST Amt</th>
                <th>Total Duty + GST</th>
                <th>Expense</th>
                <th>Total Expense</th>
                <th>Off Expense</th>
                <th>Off Total Expense</th>
                <th>Off per pc</th>
              </tr>
            </thead>
            <tfoot>
              <tr class="font-weight-bold">
                <td colspan="4" class="text-end">TOTAL</td>
                <td class="text-end">${fmt(g.official_qty, 0)}</td>
                <td class="text-end">${fmt(g.black_qty, 0)}</td>
                <td class="text-end">${fmt(g.act_qty, 0)}</td>
                <!-- <td class="text-end">${fmt(g.cbm_per_pc, 5)}</td> -->
                <td class="text-end">-</td>
                <td class="text-end">${fmt(g.off_cbm_total, 2)}</td>
                <td class="text-end">${fmt(g.actual_cbm_total, 2)}</td>
                <!-- <td class="text-end">${fmt(g.actual_cost_with_exp, 5)}</td> -->
                <td class="text-end">-</td>
                <!-- <td class="text-end">${fmt(g.rmb_per_pc, 2)}</td> -->
                <td class="text-end">-</td>
                <td class="text-end">${fmt(g.rmb_total, 2)}</td>
                <!-- <td class="text-end">${fmt(g.usd_per_pc, 2)}</td> -->
                <td class="text-end">-</td>
                <td class="text-end">${fmt(g.usd_total, 2)}</td>
                <!-- <td class="text-end">${fmt(g.cost_without_expense_rs, 2)}</td> -->
                <td class="text-end">-</td>
                <td class="text-end">${fmt(g.total_rs_without_expense, 2)}</td>
                <!-- <td class="text-end">${fmt(g.off_usd_per_pc, 2)}</td> -->
                <td class="text-end">-</td>
                <td class="text-end">${fmt(g.total_off_usd, 2)}</td>
                <!-- <td class="text-end">${fmt(g.off_rs_per_pc, 2)}</td> -->
                <td class="text-end">-</td>
                <td class="text-end">${fmt(g.total_off_rs, 2)}</td>
                <!-- <td class="text-end">${fmt(g.off_duty_percent, 2)}</td> -->
                <td class="text-end">-</td>
                <td class="text-end">${fmt(g.off_duty_amt, 2)}</td>
                <td class="text-end">${fmt(g.off_surcharge, 2)}</td>
                <td class="text-end">${fmt(g.off_taxable_value, 2)}</td>
                <!-- <td class="text-end">${fmt(g.off_gst_percent, 2)}</td> -->
                <td class="text-end">-</td>
                <td class="text-end">${fmt(g.off_gst_amt, 2)}</td>
                <td class="text-end">${fmt(g.total_duty_gst, 2)}</td>
                <td class="text-end">${fmt(g.expense, 2)}</td>
                <td class="text-end">${fmt(g.total_expense, 2)}</td>
                <td class="text-end">${fmt(g.official_expense, 2)}</td>
                <td class="text-end">${fmt(g.total_official_expense, 2)}</td>
                <!-- <td class="text-end">${fmt(g.official_exp_per_pc, 2)}</td> -->
                <td class="text-end">-</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    `);

    $wrap.append(`
      <div class="row mt-4">
        <div class="col-md-6" id="supplier-accounts-col"></div>
        <div class="col-md-6" id="expense-detail-col"></div>
      </div>
    `);

    const $accountsCol = $('#supplier-accounts-col');
    const $expenseCol = $('#expense-detail-col');

    if (Array.isArray(expenseItems) && expenseItems.length > 0) {
      let expRowsHtml = '';
      let totalNet = 0;
      let totalGst = 0;
      let totalFinal = 0;

      // Build a map of supplier ID -> supplier name
      const supplierMap = {};
      if (Array.isArray(suppliers)) {
        suppliers.forEach(s => {
          supplierMap[String(s.supplier_id)] = s.supplier_name;
        });
      }

      expenseItems.forEach(item => {
        const net = toNum(item.amount);
        const gst = toNum(item.gst_amt);
        const final = toNum(item.total_amt);
        const supplier_id = item.supplier_id ? item.supplier_id.split(',').map(id => id.trim()).filter(id => id !== '') : [];
        
        let nameHtml = `<span>${escapeHtml(item.expense_name)}</span>`;
        if (Array.isArray(suppliers) && supplier_id.length !== suppliers.length) {
          const expSupplierNames = supplier_id.map(id => supplierMap[String(id)] || 'Unknown Supplier');
          const namesTooltip = expSupplierNames.join(', ');
          nameHtml += `
            <i class="fa fa-info-circle text-info" 
               data-toggle="tooltip" 
               data-bs-placement="top" 
               title="${escapeHtml(namesTooltip)}" 
               style="cursor: pointer;"></i>
          `;
        }

        totalNet += net;
        totalGst += gst;
        totalFinal += final;

        expRowsHtml += `
          <tr>
            <td>
              <div class="d-flex justify-content-between align-items-center">
                ${nameHtml}
              </div>
            </td>
            <td class="text-end">${fmt(net, 2)}</td>
            <td class="text-end">${fmt(gst, 2)}</td>
            <td class="text-end">${fmt(final, 2)}</td>
          </tr>
        `;
      });

      $expenseCol.append(`
        <div class="supplier-section mb-2">
          <h6 class="mb-1">Expense Detail</h6>
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-sm mb-0">
              <thead>
                <tr>
                  <th>Expense Name</th>
                  <th class="text-end">Net Amount</th>
                  <th class="text-end">GST Amount</th>
                  <th class="text-end">Final Total</th>
                </tr>
              </thead>
              <tbody>${expRowsHtml}</tbody>
              <tfoot>
                <tr class="font-weight-bold">
                  <td class="text-end">TOTAL</td>
                  <td class="text-end">${fmt(totalNet, 2)}</td>
                  <td class="text-end">${fmt(totalGst, 2)}</td>
                  <td class="text-end">${fmt(totalFinal, 2)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      `);

      // Initialize tooltips in the newly added element
      if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        var tooltipTriggerList = [].slice.call($expenseCol[0].querySelectorAll('[data-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
          return new bootstrap.Tooltip(tooltipTriggerEl);
        });
      } else if ($.fn.tooltip) {
        $expenseCol.find('[data-toggle="tooltip"]').tooltip();
      }
    }

    if (Array.isArray(supplierAccounts) && supplierAccounts.length > 0) {
      supplierAccounts.forEach(acc => {
        let paymentRows = '';
        acc.payments.forEach(p => {
          paymentRows += `
            <tr>
              <td>${p.date}</td>
              <td class="text-end">${fmt(p.rmb)}</td>
              <td class="text-end">${fmt(p.usd)}</td>
              <td class="text-end">${fmt(p.inr)}</td>
            </tr>
          `;
        });

        $accountsCol.append(`
          <div class="supplier-section mb-3">
            <h6 class="mb-1">Supplier Account: ${escapeHtml(acc.supplier_name)}</h6>
            <div class="table-responsive">
              <table class="table table-bordered table-striped table-sm mb-0">
                <thead>
                  <tr class="bg-light">
                    <th>Date</th>
                    <th class="text-end">RMB</th>
                    <th class="text-end">USD</th>
                    <th class="text-end">INR</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>${acc.outstanding.date}</td>
                    <td class="text-end">${fmt(acc.outstanding.rmb)}</td>
                    <td class="text-end">${fmt(acc.outstanding.usd)}</td>
                    <td class="text-end">${fmt(acc.outstanding.inr)}</td>
                  </tr>
                  <tr>
                    <td colspan="4" class="py-0" style="background: #eee; height: 1px;"></td>
                  </tr>
                  ${paymentRows}
                </tbody>
                <tfoot>
                  <tr class="font-weight-bold" style="background: #fdfdfd;">
                    <td>Total</td>
                    <td class="text-end">${fmt(acc.total.rmb)}</td>
                    <td class="text-end">${fmt(acc.total.usd)}</td>
                    <td class="text-end">${fmt(acc.total.inr)}</td>
                  </tr>
                  <tr class="text-primary fw-bold">
                    <td>Loaded Amount</td>
                    <td class="text-end">${fmt(acc.loaded.rmb)}</td>
                    <td class="text-end">${fmt(acc.loaded.usd)}</td>
                    <td class="text-end">${fmt(acc.loaded.inr)}</td>
                  </tr>
                  <tr class="bg-dark text-white fw-bold">
                    <td>Remaining Balance</td>
                    <td class="text-end">${fmt(acc.balance.rmb)}</td>
                    <td class="text-end">${fmt(acc.balance.usd)}</td>
                    <td class="text-end">${fmt(acc.balance.inr)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        `);
      });
    }
  }


  $(document).ready(function() {
    $('#view-batch-btn').on('click', function() {
      const batchNo = ($('#batch_no').val() || '').trim();
      if (!batchNo) {
        Swal.fire('Error!', 'Please select a Batch No.', 'error');
        return;
      }

      const $btn = $(this);
      const originalText = $btn.text();
      $btn.prop('disabled', true).text('Loading...');

      $.ajax({
        type: 'POST',
        url: "<?php echo base_url(); ?>inventory/get_batch_detail_new_data",
        data: { batch_no: batchNo },
        dataType: 'json',
        success: function(res) {
          if (res && Number(res.status) === 200) {
            setHeaderFields(res.header || {});
            renderSupplierTables(res.suppliers || [], res.grand_totals || {}, res.expense_items || [], res.supplier_accounts || []);
            $('#batch-detail-wrap').removeClass('d-none');
          } else {
            $('#batch-detail-wrap').addClass('d-none');
            Swal.fire('Error!', (res && res.message) ? res.message : 'Unable to fetch batch data.', 'error');
          }
        },
        error: function() {
          $('#batch-detail-wrap').addClass('d-none');
          Swal.fire('Error!', 'Request failed. Please try again.', 'error');
        },
        complete: function() {
          $btn.prop('disabled', false).text(originalText);
        }
      });
    });
  });
</script>

