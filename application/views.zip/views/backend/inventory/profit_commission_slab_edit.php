<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body py-1 my-0">
        <?php echo form_open('inventory/profit_commission_slab/edit_post/'.$id, ['class' => 'add-ajax-redirect-form','onsubmit' => 'return checkForm(this);']);?>  
          <div class="row">
            <div class="col-12 col-sm-6 mb-1">
              <div class="form-group">
                <label>Commission From <span class="required">*</span></label>
                <input type="number" step="0.01" class="form-control" placeholder="Enter Commission From" name="comm_from" required="" value="<?php echo isset($data['comm_from']) ? $data['comm_from'] : ''; ?>">
              </div>
            </div>
            <div class="col-12 col-sm-6 mb-1">
              <div class="form-group">
                <label>Commission To <span class="required">*</span></label>
                <input type="number" step="0.01" class="form-control" placeholder="Enter Commission To" name="comm_to" required="" value="<?php echo isset($data['comm_to']) ? $data['comm_to'] : ''; ?>">
              </div>
            </div>
            <div class="col-12">
              <button type="submit" class="dt-button add-new btn btn-primary waves-effect waves-float waves-light mt-1 me-1 btnf btn_verify" name="btn_verify"><?php echo get_phrase('submit'); ?></button>
            </div>
          </div>
        <?php echo form_close(); ?>		
      </div>
    </div>
  </div>
</div>
