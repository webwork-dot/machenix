<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'login';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$r_admin      		='admin';
$r_inventory      	='inventory';
$qc_inventory      	='quality-control';
$r_production_head  ='production_head';
$r_common     		='common';
$r_hr ='hr'; 

include_once "route_master.php";
include_once "route_hrm.php";

$route[$r_inventory . '/system-password/(:num)'] = 'inventory/system_password/$1';

$route[$r_admin . '/staff'] = 'admin/staff';
$route[$r_admin . '/staff/add']    = 'admin/staff_form/staff_add';
$route[$r_admin . '/staff/edit/(:num)'] = 'admin/staff_form/staff_edit/$1';
$route[$r_admin . '/staff/change-password/(:num)'] = 'admin/staff_form/staff_change_password/$1';


$route[$r_inventory . '/manage-access'] = 'inventory/manage_access';
$route[$r_inventory . '/access/add']    = 'inventory/access_form/add';
$route[$r_inventory . '/access/edit/(:num)'] = 'inventory/access_form/edit/$1';

$route[$r_inventory . '/manage-staff'] = 'inventory/manage_staff';
$route[$r_inventory . '/staff/add']    = 'inventory/staff_form/staff_add';
$route[$r_inventory . '/staff/edit/(:num)'] = 'inventory/staff_form/staff_edit/$1';


/* Inventory */
$route[$r_inventory . '/warehouse'] = 'inventory/warehouse';
$route[$r_inventory . '/warehouse/add']    = 'inventory/warehouse_form/warehouse_add';
$route[$r_inventory . '/warehouse/edit/(:num)'] = 'inventory/warehouse_form/warehouse_edit/$1';

$route[$r_inventory . '/supplier'] = 'inventory/supplier';
$route[$r_inventory . '/supplier/add']    = 'inventory/supplier_form/supplier_add';
$route[$r_inventory . '/supplier/edit/(:num)'] = 'inventory/supplier_form/supplier_edit/$1';
$route[$r_inventory . '/supplier/ledger/(:num)'] = 'inventory/supplier_form/supplier_ledger/$1';

$route[$r_inventory . '/supplier-adjustment']                      = 'inventory/supplier_adjustment';
$route['supplier-adjustment']                                      = 'inventory/supplier_adjustment';
$route[$r_inventory . '/supplier-adjustment/add_post']             = 'inventory/supplier_adjustment/add_post';
$route[$r_inventory . '/supplier-adjustment/edit_post/(:num)']     = 'inventory/supplier_adjustment/edit_post/$1';
$route[$r_inventory . '/supplier-adjustment/delete/(:num)']        = 'inventory/supplier_adjustment/delete/$1';
$route[$r_inventory . '/add-supplier-adjustment']                  = 'inventory/supplier_adjustment_form/add';
$route['add-supplier-adjustment']                                  = 'inventory/supplier_adjustment_form/add';
$route[$r_inventory . '/edit-supplier-adjustment/(:num)']          = 'inventory/supplier_adjustment_form/edit/$1';
$route['edit-supplier-adjustment/(:num)']                          = 'inventory/supplier_adjustment_form/edit/$1';
$route[$r_inventory . '/get_supplier_adjustment']                  = 'inventory/get_supplier_adjustment';
$route['get_supplier_adjustment']                                  = 'inventory/get_supplier_adjustment';
$route[$r_inventory . '/get_batches_by_supplier_ajax']             = 'inventory/get_batches_by_supplier_ajax';
$route['get_batches_by_supplier_ajax']                             = 'inventory/get_batches_by_supplier_ajax';
$route[$r_inventory . '/get_supplier_batch_adjustment_info']      = 'inventory/get_supplier_batch_adjustment_info';
$route['get_supplier_batch_adjustment_info']                      = 'inventory/get_supplier_batch_adjustment_info';

$route[$r_inventory . '/local-supplier']                      = 'local_supplier/index';
$route[$r_inventory . '/local-supplier/add']                  = 'local_supplier/add';
$route[$r_inventory . '/local-supplier/edit/(:num)']          = 'local_supplier/edit/$1';
$route[$r_inventory . '/local-supplier/ledger/(:num)']        = 'local_supplier/ledger/$1';
$route[$r_inventory . '/local-supplier/add_post']             = 'local_supplier/index/add_post';
$route[$r_inventory . '/local-supplier/edit_post/(:num)']     = 'local_supplier/index/edit_post/$1';
$route[$r_inventory . '/local-supplier/delete/(:num)']        = 'local_supplier/index/delete/$1';
$route[$r_inventory . '/get_local_supplier']                  = 'local_supplier/get_local_supplier';

$route[$r_inventory . '/company'] = 'inventory/company';
$route[$r_inventory . '/company/add']    = 'inventory/company_form/company_add';
$route[$r_inventory . '/company/edit/(:num)'] = 'inventory/company_form/company_edit/$1';

$route[$r_inventory . '/my-company'] = 'inventory/my_company';
$route[$r_inventory . '/my-company/add']    = 'inventory/my_company_form/my_company_add';
$route[$r_inventory . '/my-company/edit/(:num)'] = 'inventory/my_company_form/my_company_edit/$1';

$route[$r_inventory . '/vendor-adjustment']                      = 'inventory/vendor_adjustment';
$route['vendor-adjustment']                                      = 'inventory/vendor_adjustment';
$route[$r_inventory . '/vendor-adjustment/add_post']             = 'inventory/vendor_adjustment/add_post';
$route[$r_inventory . '/vendor-adjustment/edit_post/(:num)']     = 'inventory/vendor_adjustment/edit_post/$1';
$route[$r_inventory . '/vendor-adjustment/delete/(:num)']        = 'inventory/vendor_adjustment/delete/$1';
$route[$r_inventory . '/add-vendor-adjustment']                  = 'inventory/vendor_adjustment_form/add';
$route['add-vendor-adjustment']                                  = 'inventory/vendor_adjustment_form/add';
$route[$r_inventory . '/edit-vendor-adjustment/(:num)']          = 'inventory/vendor_adjustment_form/edit/$1';
$route['edit-vendor-adjustment/(:num)']                          = 'inventory/vendor_adjustment_form/edit/$1';
$route[$r_inventory . '/get_vendor_adjustment']                  = 'inventory/get_vendor_adjustment';
$route['get_vendor_adjustment']                                  = 'inventory/get_vendor_adjustment';
$route[$r_inventory . '/get_vendor_ledger_summary_ajax']          = 'inventory/get_vendor_ledger_summary_ajax';
$route['get_vendor_ledger_summary_ajax']                          = 'inventory/get_vendor_ledger_summary_ajax';

$route[$r_inventory . '/expense-type'] = 'inventory/expense_type';
$route[$r_inventory . '/expense-type/add']    = 'inventory/expense_type_form/expense_type_add';
$route[$r_inventory . '/expense-type/edit/(:num)'] = 'inventory/expense_type_form/expense_type_edit/$1';

$route[$r_inventory . '/product-unit'] = 'inventory/product_unit';
$route[$r_inventory . '/product-unit/add']    = 'inventory/product_unit_form/product_unit_add';
$route[$r_inventory . '/product-unit/edit/(:num)'] = 'inventory/product_unit_form/product_unit_edit/$1';

$route[$r_inventory . '/charges'] = 'inventory/other_charges';
$route[$r_inventory . '/charges/add'] = 'inventory/other_charges_form/other_charges_add';
$route[$r_inventory . '/charges/edit/(:num)'] = 'inventory/other_charges_form/other_charges_edit/$1';

$route[$r_inventory . '/commission-slab'] = 'inventory/commission_slab';
$route[$r_inventory . '/commission-slab/add'] = 'inventory/commission_slab_form/commission_slab_add';
$route[$r_inventory . '/commission-slab/edit/(:num)'] = 'inventory/commission_slab_form/commission_slab_edit/$1';

$route[$r_inventory . '/profit-commission-slab'] = 'inventory/profit_commission_slab';
$route[$r_inventory . '/profit-commission-slab/add'] = 'inventory/profit_commission_slab_form/profit_commission_slab_add';
$route[$r_inventory . '/profit-commission-slab/edit/(:num)'] = 'inventory/profit_commission_slab_form/profit_commission_slab_edit/$1';

$route[$r_inventory . '/bank-accounts'] = 'inventory/bank_accounts';
$route[$r_inventory . '/bank-accounts/add']    = 'inventory/bank_accounts_form/bank_accounts_add';
$route[$r_inventory . '/bank-accounts/edit/(:num)'] = 'inventory/bank_accounts_form/bank_accounts_edit/$1';

$route[$r_inventory . '/customer'] = 'inventory/customer';
$route[$r_inventory . '/customer/add']    = 'inventory/customer_form/customer_add';
$route[$r_inventory . '/customer/edit/(:num)'] = 'inventory/customer_form/customer_edit/$1';
$route[$r_inventory . '/customer/ledger/(:num)'] = 'inventory/customer_form/customer_ledger/$1';

$route[$r_inventory . '/customer-adjustment']                      = 'inventory/customer_adjustment';
$route['customer-adjustment']                                      = 'inventory/customer_adjustment';
$route[$r_inventory . '/customer-adjustment/add_post']             = 'inventory/customer_adjustment/add_post';
$route[$r_inventory . '/customer-adjustment/edit_post/(:num)']     = 'inventory/customer_adjustment/edit_post/$1';
$route[$r_inventory . '/customer-adjustment/delete/(:num)']        = 'inventory/customer_adjustment/delete/$1';
$route[$r_inventory . '/add-customer-adjustment']                  = 'inventory/customer_adjustment_form/add';
$route['add-customer-adjustment']                                  = 'inventory/customer_adjustment_form/add';
$route[$r_inventory . '/edit-customer-adjustment/(:num)']          = 'inventory/customer_adjustment_form/edit/$1';
$route['edit-customer-adjustment/(:num)']                          = 'inventory/customer_adjustment_form/edit/$1';
$route[$r_inventory . '/get_customer_adjustment']                  = 'inventory/get_customer_adjustment';
$route['get_customer_adjustment']                                  = 'inventory/get_customer_adjustment';
$route[$r_inventory . '/get_customer_ledger_summary_ajax']          = 'inventory/get_customer_ledger_summary_ajax';
$route['get_customer_ledger_summary_ajax']                          = 'inventory/get_customer_ledger_summary_ajax';


$route[$r_inventory . '/leads/add']               = 'inventory/leads_form/leads_add';
$route[$r_inventory . '/leads/edit/(:num)']       = 'inventory/leads_form/leads_edit/$1';
$route[$r_inventory . '/leads/move/(:num)']       = 'inventory/leads_form/leads_move/$1';
$route[$r_inventory . '/leads/(:any)']            = 'inventory/leads/$1';
// $route[$r_inventory . '/leads/(:any)']            = 'inventory/leads_form/leads/$1';

$route[$r_inventory . '/category']                      	= 'inventory/categories';
$route[$r_inventory . '/category/add']                  	= 'inventory/category_form/add';
$route[$r_inventory . '/category/edit/(:num)']          	= 'inventory/category_form/edit/$1';

$route[$r_inventory . '/product-size']                  	= 'inventory/product_size';
$route[$r_inventory . '/product-size/add']              	= 'inventory/product_size_form/add';
$route[$r_inventory . '/product-size/edit/(:num)']      	= 'inventory/product_size_form/edit/$1';

$route[$r_inventory . '/product-color']                 	= 'inventory/product_color';
$route[$r_inventory . '/product-color/add']             	= 'inventory/product_color_form/add';
$route[$r_inventory . '/product-color/edit/(:num)']     	= 'inventory/product_color_form/edit/$1';

$route[$r_inventory . '/raw-products']              = 'inventory/raw_products';
$route[$r_inventory . '/import-products']           = 'inventory/raw_products_form/import';
$route[$r_inventory . '/raw-products/add']          = 'inventory/raw_products_form/add';
$route[$r_inventory . '/raw-products/edit/(:num)']  = 'inventory/raw_products_form/edit/$1';

$route[$r_inventory . '/local-products']                      = 'local_products/index';
$route[$r_inventory . '/local-products/add']                  = 'local_products/add';
$route[$r_inventory . '/local-products/edit/(:num)']          = 'local_products/edit/$1';
$route[$r_inventory . '/local-products/add_post']             = 'local_products/index/add_post';
$route[$r_inventory . '/local-products/edit_post/(:num)']     = 'local_products/index/edit_post/$1';
$route[$r_inventory . '/local-products/delete/(:num)']        = 'local_products/index/delete/$1';
$route[$r_inventory . '/local-products/delete_variation']     = 'local_products/local_products_delete_variation';
$route[$r_inventory . '/local-products/delete_sku']           = 'local_products/local_products_delete_sku';
$route[$r_inventory . '/get_local_products']                  = 'local_products/get_local_products';

$route[$r_inventory . '/product-formula']                     = 'inventory/product_formula';
$route[$r_inventory . '/product-formula/add']                 = 'inventory/product_formula_form/product_formula_add';
$route[$r_inventory . '/product-formula/edit/(:num)']         = 'inventory/product_formula_form/product_formula_edit/$1';

$route[$r_inventory . '/purchase-order'] = 'inventory/purchase_order/local';
$route[$r_inventory . '/get_purchase_order_local'] = 'inventory/get_purchase_order_local';
$route[$r_inventory . '/purchase-order/add-local']    = 'inventory/purchase_order_form/add_local';
$route[$r_inventory . '/purchase-order/edit-local/(:num)'] = 'inventory/purchase_order_form/edit_local/$1';
$route[$r_inventory . '/purchase-order/edit-local-post/(:num)'] = 'inventory/purchase_order/edit_local_post/$1';
$route[$r_inventory . '/purchase-order/delete-local/(:num)'] = 'inventory/purchase_order/delete_local/$1';
$route[$r_inventory . '/receive_company_purchase_qty'] = 'inventory/receive_company_purchase_qty';

$route[$r_inventory . '/formula-product-order'] = 'inventory/formula_product_order';
$route[$r_inventory . '/formula-product-order/add'] = 'inventory/formula_product_order_form/add';
$route[$r_inventory . '/formula-product-order/add_post'] = 'inventory/formula_product_order_add_post';
$route[$r_inventory . '/formula-product-order/get_ingredients'] = 'inventory/get_formula_ingredients_details';


$route[$r_inventory . '/imp-purchase-order']  = 'inventory/purchase_order/import';
$route[$r_inventory . '/purchase-order/add-import']    = 'inventory/purchase_order_form/add_import';
$route[$r_inventory . '/purchase-order/edit-import/(:num)'] = 'inventory/purchase_order_form/edit_import/$1';
$route[$r_inventory . '/priority-po']         = 'inventory/priority_po';
$route[$r_inventory . '/loading-list-po']     = 'inventory/loading_list_po';
$route[$r_inventory . '/loading-list-po/add']     = 'inventory/loading_list_po_form/add';
$route[$r_inventory . '/po-purchase-in']     = 'inventory/po_purchase_in';

$route[$r_inventory . '/po-expense']          = 'inventory/po_expense';
$route[$r_inventory . '/po-expense/add']      = 'inventory/po_expense_form/add';
$route[$r_inventory . '/po-expense/edit/(:num)']  = 'inventory/po_expense_form/edit/$1';
$route[$r_inventory . '/pending-po']          = 'inventory/pending_po';

$route[$r_inventory . '/payments']          = 'inventory/payments';
$route[$r_inventory . '/payments/add']      = 'inventory/payments_form/add';
$route[$r_inventory . '/payments/edit/(:num)']      = 'inventory/payments_form/edit/$1';

$route[$r_inventory . '/vendor-payments']          = 'inventory/vendor_payments';
$route[$r_inventory . '/vendor-payments/add']      = 'inventory/vendor_payments_form/add';
$route[$r_inventory . '/vendor-payments/edit/(:num)']      = 'inventory/vendor_payments_form/edit/$1';
$route[$r_inventory . '/vendor-ledger/(:num)']          = 'inventory/vendor_ledger/$1';

$route[$r_inventory . '/payment-receipt']                  = 'inventory/payment_receipt';
$route[$r_inventory . '/payment-receipt/add']              = 'inventory/payment_receipt_form/add';
$route[$r_inventory . '/payment-receipt/edit/(:num)']     = 'inventory/payment_receipt_form/edit/$1';

$route[$r_inventory . '/payment-reconciliation']                  = 'inventory/payment_reconciliation';
$route[$r_inventory . '/payment-reconciliation/approve/(:num)']  = 'inventory/payment_reconciliation/approve/$1';

$route[$r_inventory . '/cash-collection']                         = 'inventory/cash_collection';
$route[$r_inventory . '/cash-collection/approve/(:num)']         = 'inventory/cash_collection/approve/$1';

$route[$r_inventory . '/petty-cash']                  = 'inventory/petty_cash';
$route[$r_inventory . '/petty-cash/add']              = 'inventory/petty_cash_form/add';
$route[$r_inventory . '/petty-cash/edit/(:num)']     = 'inventory/petty_cash_form/edit/$1';

$route[$r_inventory . '/purchase-order-entry'] = 'inventory/purchase_order_entry';
$route[$r_inventory . '/purchase-order/edit/(:num)'] = 'inventory/purchase_order_form/edit/$1';
$route[$r_inventory . '/purchase-order-entry/view/(:num)'] = 'inventory/purchase_order_form/view_entry/$1';

$route[$r_inventory . '/purchase-reports'] = 'inventory/purchase_reports';
$route[$r_inventory . '/purchase-reports/delete/(:any)'] = 'inventory/purchase_reports/delete/$1';
$route[$r_inventory . '/sales-reports'] = 'inventory/sales_reports';
$route[$r_inventory . '/sales-return-reports'] = 'inventory/sales_return_reports';
$route[$r_inventory . '/stock-reports'] = 'inventory/stock_reports';

$route[$r_inventory . '/purchase-entry'] = 'inventory/purchase_entry';
$route[$r_inventory . '/purchase-entry/add']    = 'inventory/purchase_entry_form/add';
$route[$r_inventory . '/purchase-entry/edit/(:num)'] = 'inventory/purchase_entry_form/edit/$1';

$route[$r_inventory . '/reserved-order'] = 'inventory/reserved_order';
$route[$r_inventory . '/reserved-order/add'] = 'inventory/reserved_order_form/add';

$route[$r_inventory . '/damage-stock'] = 'inventory/damage_stock';
$route[$r_inventory . '/damage-stock/add'] = 'inventory/damage_stock_form/add';
$route[$r_inventory . '/damage-stock/view/(:num)'] = 'inventory/damage_stock_form/view/$1';

$route[$r_inventory . '/damage-stock-product'] = 'inventory/damage_stock_product';
$route[$r_inventory . '/scrap-product'] = 'inventory/scrap_product';

$route[$r_inventory . '/batch-detail'] = 'inventory/batch_detail';

$route[$r_inventory . '/my-stock'] = 'inventory/my_stock';
$route[$r_inventory . '/overall-stock'] = 'inventory/overall_stock';
// $route[$r_inventory . '/get-overall-stock'] = 'inventory/get_overall_stock';
$route[$r_inventory . '/my-stock-company/(:num)'] = 'inventory/my_stock_company/$1';
// $route[$r_inventory . '/get-overall-stock-company'] = 'inventory/get_overall_stock_company';
$route[$r_inventory . '/my-stock-batch/(:any)/(:any)'] = 'inventory/my_stock_batch/$1/$2';
$route[$r_inventory . '/my-stock-history/(:any)'] = 'inventory/my_stock_history/$1';
$route[$r_inventory . '/qc-pending'] = 'inventory/qc_pending';
$route[$r_inventory . '/low-stock'] = 'inventory/low_stock';
$route[$r_inventory . '/get-low-stock'] = 'inventory/get_low_stock';

$route[$r_inventory . '/stock-transfer'] = 'inventory/stock_transfer';
$route[$r_inventory . '/stock-transfer-list'] = 'inventory/stock_transfer_list';

$route[$r_inventory . '/goods-return'] 		= 'inventory/goods_return';
$route[$r_inventory . '/goods-return/add'] 	= 'inventory/goods_return_form/add';
$route[$r_inventory . '/goods-return/get-invoices-or-orders'] = 'inventory/get_invoices_or_orders_by_customer';
$route[$r_inventory . '/goods-return/get-details'] = 'inventory/get_invoice_or_order_details';
$route[$r_inventory . '/goods-return/get-customer-product-returns'] = 'inventory/get_customer_product_returns';
$route[$r_inventory . '/goods-return/view/(:any)'] 	= 'inventory/goods_return_form/view/$1';

$route[$r_inventory . '/payment-reconceliation'] 		= 'inventory/payment_reconceliation';
$route[$r_inventory . '/payment-reconceliation/add'] 	= 'inventory/payment_reconceliation_form/add';
$route[$r_inventory . '/payment-reconceliation/view/(:any)'] 	= 'inventory/payment_reconceliation_form/view/$1';

/*Common*/
$route[$r_common . '/reminder']			    = 'common/reminder';
$route[$r_common . '/reminder-done']		= 'common/reminder_done';
$route[$r_common . '/reminder/add']    		= 'common/reminder_form/add';
$route[$r_common . '/reminder/edit/(:num)'] = 'common/reminder_form/edit/$1';

$route[$qc_inventory . '/raw-material'] = 'quality_control/raw_material';
$route[$qc_inventory . '/raw-material-done'] = 'quality_control/raw_material_done';

$route[$r_inventory . '/import-order'] = 'inventory/import_order';

$route[$r_inventory . '/import-purchase-order'] = 'inventory/import_purchase_order';

$route[$r_inventory . '/black-order'] = 'inventory/black_order';
$route[$r_inventory . '/conversion-order'] = 'inventory/conversion_order';
$route[$r_inventory . '/conversion-order/add'] = 'inventory/conversion_order_form/add';

$route[$r_inventory . '/company-sales']                  = 'inventory/company_sales';
$route[$r_inventory . '/company-sales/add']              = 'inventory/company_sales_form/add';
$route[$r_inventory . '/company-sales/add_post']         = 'inventory/company_sales/add_post';
$route[$r_inventory . '/company-sales/delete/(:num)']    = 'inventory/company_sales/delete/$1';
$route[$r_inventory . '/get_company_sales']              = 'inventory/get_company_sales';
$route[$r_inventory . '/get_company_details_ajax']       = 'inventory/get_company_details_ajax';
$route[$r_inventory . '/get_company_sales_batch_details'] = 'inventory/get_company_sales_batch_details';
$route[$r_inventory . '/company-sales/product_details'] = 'inventory/get_company_sales_product_details';

$route[$r_inventory . '/customer-quotations']                  = 'inventory/customer_quotations';
$route['customer-quotations']                                  = 'inventory/customer_quotations';
$route[$r_inventory . '/customer-quotations/add']              = 'inventory/customer_quotations_form/add';
$route[$r_inventory . '/customer-quotations/add_post']         = 'inventory/customer_quotations/add_post';
$route[$r_inventory . '/customer-quotations/edit/(:num)']      = 'inventory/customer_quotations_form/edit/$1';
$route[$r_inventory . '/customer-quotations/edit_post/(:num)'] = 'inventory/customer_quotations/edit_post/$1';
$route[$r_inventory . '/customer-quotations/delete/(:num)']    = 'inventory/customer_quotations/delete/$1';
$route[$r_inventory . '/get_customer_quotations']              = 'inventory/get_customer_quotations';

$route[$r_inventory . '/sales-order'] = 'inventory/sales_order';
$route[$r_inventory . '/get_sales_order_product_wise'] = 'inventory/get_sales_order_product_wise';
$route[$r_inventory . '/sales-commission'] = 'inventory/sales_commission';
$route[$r_inventory . '/get_sales_commission'] = 'inventory/get_sales_commission';
$route[$r_inventory . '/get_completed_sales_commission'] = 'inventory/get_completed_sales_commission';
$route[$r_inventory . '/make_sales_commission_payment'] = 'inventory/make_sales_commission_payment';
$route[$r_inventory . '/replace-products'] = 'inventory/replace_products';
$route[$r_inventory . '/get_replace_products'] = 'inventory/get_replace_products';
$route[$r_inventory . '/get_pending_replace_products_by_supplier'] = 'inventory/get_pending_replace_products_by_supplier';
$route[$r_inventory . '/sales-order/add']    = 'inventory/sales_order_form/add';
$route[$r_inventory . '/sales-invoice/add']    = 'inventory/sales_order_form/invoice_add';
$route[$r_inventory . '/sales-invoice/edit/(:num)'] = 'inventory/sales_invoice_form/edit/$1';
$route[$r_inventory . '/sales-invoice/edit_post/(:num)'] = 'inventory/sales_invoice_edit_post/$1';
$route[$r_inventory . '/sales_invoice_delete/(:num)'] = 'inventory/sales_invoice_delete/$1';
$route[$r_inventory . '/sales_invoice_cancel/(:num)'] = 'inventory/sales_invoice_cancel/$1';
$route[$r_inventory . '/sales-order/approve/(:num)']    = 'inventory/sales_order_form/approve/$1';
$route[$r_inventory . '/sales-order/edit/(:num)']    = 'inventory/sales_order_form/edit/$1';
$route[$r_inventory . '/sales-order/edit-order/(:num)']    = 'inventory/sales_order_form/edit_order/$1';

$route[$r_inventory . '/sales-order/view/(:num)']    = 'inventory/sales_order_form/view/$1';
$route[$r_inventory . '/sales-order/not-uploaded/(:num)']    = 'inventory/sales_order_form/excel/$1';
$route[$r_inventory . '/sales-order/products/(:num)']    = 'inventory/sales_order_form/products/$1';

$route[$r_inventory . '/purchase-return'] = 'inventory/purchase_return';
$route[$r_inventory . '/purchase-return/add'] = 'inventory/purchase_return_form/add';
$route[$r_inventory . '/purchase-return/view/(:any)'] 	= 'inventory/purchase_return_form/view/$1';

